import static spark.Spark.*;

public class GenoBankServer {
    public static void main(String[] args) {
        
        port(8080);

       
        get("/search", (req, res) -> {
            String query = req.queryParams("query");
           
            String[] searchResults = performSearch(query);

           
            res.type("application/json");
            return searchResults;
        });
    }

    public static String[] performSearch(String query) {
       
        String[] searchResults = {
                "Result 1",
                "Result 2",
                "Result 3"
        };

        return searchResults;
    }
}
