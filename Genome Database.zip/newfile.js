
document.addEventListener('DOMContentLoaded', function() {
  var searchForm = document.getElementById('searchForm');
  searchForm.addEventListener('submit', function(event) {
    event.preventDefault();
    var query = document.getElementById('queryInput').value;
    performSearch(query);
  });
});

function performSearch(query) {
 
  var searchResults = [
    { id: 1, title: 'Result 1', description: 'This is the first search result.' },
    { id: 2, title: 'Result 2', description: 'This is the second search result.' },
    { id: 3, title: 'Result 3', description: 'This is the third search result.' }
  ];

  displaySearchResults(searchResults);
}

function displaySearchResults(results) {
  var searchResultsContainer = document.getElementById('searchResults');
  searchResultsContainer.innerHTML = '';

  results.forEach(function(result) {
    var card = document.createElement('div');
    card.className = 'card mb-2';

    var cardBody = document.createElement('div');
    cardBody.className = 'card-body';

    var cardTitle = document.createElement('h5');
    cardTitle.className = 'card-title';
    cardTitle.textContent = result.title;

    var cardText = document.createElement('p');
    cardText.className = 'card-text';
    cardText.textContent = result.description;

    cardBody.appendChild(cardTitle);
    cardBody.appendChild(cardText);
    card.appendChild(cardBody);

    searchResultsContainer.appendChild(card);
  });
}
